<?php
require_once 'db_connect.php';
$id=$_GET['id']??null;
if($id){ $stmt=$conn->prepare("DELETE FROM students WHERE id=:id"); $stmt->execute([':id'=>$id]); }
header("Location: list_students.php"); exit;
