<?php
require_once 'db_connect.php';
$errors=[]; $success=''; $id=$_GET['id']??null;
if(!$id) die("ID missing");
$student=$conn->prepare("SELECT * FROM students WHERE id=:id");
$student->execute([':id'=>$id]); $student=$student->fetch(PDO::FETCH_ASSOC);
if(!$student) die("Student not found");
if($_SERVER['REQUEST_METHOD']==='POST'){
    $fullname=trim($_POST['fullname']);
    $matricule=trim($_POST['matricule']);
    $group_id=trim($_POST['group_id']);
    if(!$fullname) $errors[]="Full name required";
    if(!$matricule) $errors[]="Matricule required";
    if(!$group_id) $errors[]="Group required";
    if(empty($errors)){
        $stmt=$conn->prepare("UPDATE students SET fullname=:fullname,matricule=:matricule,group_id=:group_id WHERE id=:id");
        $stmt->execute([':fullname'=>$fullname,':matricule'=>$matricule,':group_id'=>$group_id,':id'=>$id]);
        $success="Student updated successfully";
        $student=['fullname'=>$fullname,'matricule'=>$matricule,'group_id'=>$group_id];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Update Student</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<h2>Update Student</h2>
<?php if($errors){ echo '<div class="error"><ul>'; foreach($errors as $e) echo "<li>$e</li>"; echo '</ul></div>'; }
if($success) echo "<div class='success'>$success</div>"; ?>
<form method="post">
<input type="text" name="fullname" value="<?php echo $student['fullname']; ?>">
<input type="text" name="matricule" value="<?php echo $student['matricule']; ?>">
<input type="text" name="group_id" value="<?php echo $student['group_id']; ?>">
<button type="submit">Update</button>
</form>
<p><a href="list_students.php">Back to List</a></p>
</div>
</body>
</html>
