<?php
require_once 'db_connect.php';
$success=''; $errors=[];
if($_SERVER['REQUEST_METHOD']==='POST'){
    $course=trim($_POST['course']);
    $group=trim($_POST['group']);
    $professor=trim($_POST['professor']);
    if(!$course || !$group || !$professor) $errors[]="All fields required";
    if(empty($errors)){
        $stmt=$conn->prepare("INSERT INTO attendance_sessions(course_name,group_id,opened_by,session_date,status) VALUES(:course,:group,:prof,:date,'open')");
        $stmt->execute([':course'=>$course,':group'=>$group,':prof'=>$professor,':date'=>date('Y-m-d')]);
        $success="Session created successfully!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Create Session</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<h2>Create Attendance Session</h2>
<?php if($errors){ echo '<div class="error"><ul>'; foreach($errors as $e) echo "<li>$e</li>"; echo '</ul></div>'; }
if($success) echo "<div class='success'>$success</div>"; ?>
<form method="post">
<input type="text" name="course" placeholder="Course Name">
<input type="text" name="group" placeholder="Group ID">
<input type="text" name="professor" placeholder="Professor Name">
<button type="submit">Create Session</button>
</form>
<p><a href="list_sessions.php">View Sessions</a></p>
</div>
</body>
</html>
