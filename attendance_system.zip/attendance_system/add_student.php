<?php
require_once 'db_connect.php';
$errors=[]; $success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $fullname=trim($_POST['fullname']);
    $matricule=trim($_POST['matricule']);
    $group_id=trim($_POST['group_id']);
    if(!$fullname) $errors[]="Full name required";
    if(!$matricule) $errors[]="Matricule required";
    if(!$group_id) $errors[]="Group required";
    if(empty($errors)){
        try{
            $stmt=$conn->prepare("INSERT INTO students(fullname,matricule,group_id) VALUES(:fullname,:matricule,:group_id)");
            $stmt->execute([':fullname'=>$fullname,':matricule'=>$matricule,':group_id'=>$group_id]);
            $success="Student added successfully!";
        }catch(PDOException $e){ $errors[]="Error: ".$e->getMessage(); }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Add Student</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<h2>Add Student</h2>
<?php if($errors){ echo '<div class="error"><ul>'; foreach($errors as $e) echo "<li>$e</li>"; echo '</ul></div>'; }
if($success) echo "<div class='success'>$success</div>"; ?>
<form method="post">
<input type="text" name="fullname" placeholder="Full Name">
<input type="text" name="matricule" placeholder="Matricule">
<input type="text" name="group_id" placeholder="Group">
<button type="submit">Add Student</button>
</form>
<p><a href="list_students.php">View Students</a></p>
</div>
</body>
</html>

