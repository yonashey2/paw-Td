<?php
define('DB_HOST', 'localhost'); // عادة localhost
define('DB_USER', 'root');      // اسم المستخدم WAMP
define('DB_PASS', '');          // كلمة المرور عادة فارغة
define('DB_NAME', 'attendance_system'); // يجب أن تطابق قاعدة البيانات في phpMyAdmin
?>
