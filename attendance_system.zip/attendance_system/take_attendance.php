<?php
require_once 'db_connect.php';
$date=date('Y-m-d');
$students=$conn->query("SELECT * FROM students ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
$session_id=$_GET['session_id']??null;
$success=''; $error='';
if(!$session_id) die("Session ID missing");

// تحقق من أن الجلسة مفتوحة
$session=$conn->prepare("SELECT * FROM attendance_sessions WHERE id=:id");
$session->execute([':id'=>$session_id]);
$session=$session->fetch(PDO::FETCH_ASSOC);
if(!$session) die("Session not found");
if($session['status']!='open') die("Session is closed");

if($_SERVER['REQUEST_METHOD']==='POST'){
    foreach($students as $s){
        $status=$_POST['status'][$s['id']]??'absent';
        $stmt=$conn->prepare("INSERT INTO attendance_records(session_id,student_id,status) VALUES(:session,:student,:status)");
        $stmt->execute([':session'=>$session_id,':student'=>$s['id'],':status'=>$status]);
    }
    $success="Attendance saved successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Take Attendance</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<h2>Take Attendance - <?php echo $session['course_name'];?> (<?php echo $session['group_id'];?>)</h2>
<?php if($error) echo "<div class='error'>$error</div>"; if($success) echo "<div class='success'>$success</div>"; ?>
<form method="post">
<table>
<tr><th>ID</th><th>Name</th><th>Group</th><th>Status</th></tr>
<?php foreach($students as $s): ?>
<tr>
<td><?php echo $s['id'];?></td>
<td><?php echo $s['fullname'];?></td>
<td><?php echo $s['group_id'];?></td>
<td>
<select name="status[<?php echo $s['id'];?>]">
<option value="present">Present</option>
<option value="absent">Absent</option>
</select>
</td>
</tr>
<?php endforeach; ?>
</table>
<button type="submit">Submit Attendance</button>
</form>
</div>
</body>
</html>
