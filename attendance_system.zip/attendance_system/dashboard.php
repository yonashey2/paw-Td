<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Attendance System Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body { 
    font-family: 'Poppins', sans-serif; 
    background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%);
    margin: 0; 
    padding: 0;
}
.container { 
    max-width: 1000px; 
    margin: 40px auto; 
    background: #fff; 
    padding: 30px; 
    border-radius: 20px; 
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}
h2 { 
    color: #333; 
    text-align: center; 
    font-size: 28px;
    margin-bottom: 40px;
}

/* Dashboard cards */
.dashboard { 
    display: flex; 
    flex-wrap: wrap; 
    justify-content: center; 
    gap: 25px; 
}
.card { 
    background: #fff; 
    padding: 25px; 
    border-radius: 20px; 
    box-shadow: 0 5px 15px rgba(0,0,0,0.1); 
    width: 200px; 
    text-align: center; 
    transition: 0.5s; 
    cursor: pointer; 
    position: relative;
}
.card:hover { 
    transform: translateY(-10px) scale(1.05); 
    box-shadow: 0 15px 25px rgba(0,0,0,0.2);
}
.card img { 
    width: 70px; 
    margin-bottom: 15px; 
}
.card h3 { 
    margin: 0; 
    color: #444; 
    font-size: 18px; 
}

/* Navbar */
nav { 
    text-align:center; 
    padding:15px; 
    background:#4CAF50; 
    color:#fff; 
    font-size:22px; 
    border-radius:10px; 
    margin-bottom: 30px;
}
</style>
</head>
<body>
<nav>Attendance System</nav>
<div class="container">
<h2>Dashboard</h2>
<div class="dashboard">
    <!-- Add Student -->
    <div class="card" style="background: linear-gradient(to top, #FFDEE9 0%, #B5FFFC 100%);" onclick="location.href='add_student.php'">
        <img src="assets/add.png" alt="Add Student">
        <h3>Add Student</h3>
    </div>
    
    <!-- Student List -->
    <div class="card" style="background: linear-gradient(to top, #C1F0F6 0%, #FFDEE9 100%);" onclick="location.href='list_students.php'">
        <img src="assets/list.png" alt="Student List">
        <h3>Student List</h3>
    </div>
    
    <!-- Create Session -->
    <div class="card" style="background: linear-gradient(to top, #FFEDBC 0%, #FFABAB 100%);" onclick="location.href='create_session.php'">
        <img src="assets/session.png" alt="Create Session">
        <h3>Create Session</h3>
    </div>
    
    <!-- Sessions List -->
    <div class="card" style="background: linear-gradient(to top, #D5F2E3 0%, #A1C4FD 100%);" onclick="location.href='list_sessions.php'">
        <img src="assets/list_sessions.png" alt="Sessions List">
        <h3>Sessions List</h3>
    </div>
    
    <!-- Take Attendance -->
    <div class="card" style="background: linear-gradient(to top, #FBD3E9 0%, #BB377D 100%);" 
         onclick="location.href='take_attendance.php?session_id=1'">
        <img src="assets/attendance.png" alt="Take Attendance">
        <h3>Take Attendance</h3>
    </div>
</div>
</div>
</body>
</html>
