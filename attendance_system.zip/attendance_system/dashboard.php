<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Attendance System Dashboard</title>
<link rel="stylesheet" href="style.css">
<style>
.dashboard { display: flex; flex-wrap: wrap; justify-content: center; gap: 20px; margin-top: 30px; }
.card { background: #fff; padding: 30px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.2); width: 200px; text-align: center; transition: 0.3s; cursor: pointer; }
.card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.3); }
.card img { width: 60px; margin-bottom: 15px; }
.card h3 { margin: 0; color: #333; }
</style>
</head>
<body>
<div class="container">
<h2>Welcome to Attendance System</h2>
<div class="dashboard">
    <div class="card" onclick="location.href='add_student.php'">
        <img src="assets/add.png" alt="Add Student">
        <h3>Add Student</h3>
    </div>
    <div class="card" onclick="location.href='list_students.php'">
        <img src="assets/list.png" alt="Student List">
        <h3>Student List</h3>
    </div>
    <div class="card" onclick="location.href='create_session.php'">
        <img src="assets/session.png" alt="Create Session">
        <h3>Create Session</h3>
    </div>
    <div class="card" onclick="location.href='list_sessions.php'">
        <img src="assets/list_sessions.png" alt="Sessions List">
        <h3>Sessions List</h3>
    </div>
    <div class="card" onclick="location.href='take_attendance.php?session_id=1'">
        <img src="assets/attendance.png" alt="Take Attendance">
        <h3>Take Attendance</h3>
    </div>
</div>
</div>
</body>
</html>
