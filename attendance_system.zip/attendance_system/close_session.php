<?php
require_once 'db_connect.php';
$id=$_GET['id']??null;
if($id){ $stmt=$conn->prepare("UPDATE attendance_sessions SET status='closed' WHERE id=:id"); $stmt->execute([':id'=>$id]); }
header("Location: list_sessions.php"); exit;
