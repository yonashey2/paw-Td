<?php
require_once 'db_connect.php';
$students=$conn->query("SELECT * FROM students ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Students List</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<h2>Students List</h2>
<p><a href="add_student.php">Add New Student</a></p>
<table>
<tr><th>ID</th><th>Full Name</th><th>Matricule</th><th>Group</th><th>Actions</th></tr>
<?php foreach($students as $s): ?>
<tr>
<td><?php echo $s['id'];?></td>
<td><?php echo $s['fullname'];?></td>
<td><?php echo $s['matricule'];?></td>
<td><?php echo $s['group_id'];?></td>
<td><a href="update_student.php?id=<?php echo $s['id'];?>">Edit</a> | <a href="delete_student.php?id=<?php echo $s['id'];?>" onclick="return confirm('Delete?')">Delete</a></td>
</tr>
<?php endforeach; ?>
</table>
</div>
</body>
</html>
