<?php
require_once 'db_connect.php';
$sessions=$conn->query("SELECT * FROM attendance_sessions ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Sessions List</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<h2>Attendance Sessions</h2>
<p><a href="create_session.php">Create New Session</a></p>
<table>
<tr><th>ID</th><th>Course</th><th>Group</th><th>Professor</th><th>Date</th><th>Status</th><th>Actions</th></tr>
<?php foreach($sessions as $s): ?>
<tr>
<td><?php echo $s['id'];?></td>
<td><?php echo $s['course_name'];?></td>
<td><?php echo $s['group_id'];?></td>
<td><?php echo $s['opened_by'];?></td>
<td><?php echo $s['session_date'];?></td>
<td><?php echo $s['status'];?></td>
<td><?php if($s['status']=='open') echo "<a href='close_session.php?id={$s['id']}'>Close</a>"; ?></td>
</tr>
<?php endforeach; ?>
</table>
</div>
</body>
</html>
