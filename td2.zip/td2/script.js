// script.js
const STORAGE_KEY = 'attendance_students_v1';
const SESSIONS = 6;

// helpers
function loadStudents() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch (e) {
    console.error(e);
    return [];
  }
}
function saveStudents(list) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

// default sample data (used by "Add sample students" button)
function sampleStudents() {
  return [
    {
      student_id: '1201', last_name: 'Ahmed', first_name: 'Sara',
      email: 'sara@example.com',
      sessions: [true, true, false, true, true, false],
      participations: [true, false, false, true, true, false]
    },
    {
      student_id: '1202', last_name: 'Yacine', first_name: 'Ali',
      email: 'ali@example.com',
      sessions: [true, false, true, true, true, true],
      participations: [true, true, true, true, false, true]
    },
    {
      student_id: '1203', last_name: 'Houcine', first_name: 'Rania',
      email: 'rania@example.com',
      sessions: [true, true, false, true, true, false],
      participations: [true, false, false, true, false, false]
    }
  ];
}

// compute absences (present = true => not absence)
function computeAbsences(sessions) {
  let abs = 0;
  for (let i=0; i<SESSIONS; i++) if (!sessions[i]) abs++;
  return abs;
}
function computeParticipation(parts) {
  let p = 0; for (let i=0;i<SESSIONS;i++) if (parts[i]) p++; return p;
}
function messageFor(abs, part) {
  if (abs >= 5) return 'Excluded – too many absences – You need to participate more';
  if (abs >= 3) return 'Warning – attendance low – You need to participate more';
  // abs < 3
  if (part >= 4) return 'Good attendance – Excellent participation';
  return 'Good attendance – Keep participating';
}

// render table (for index.html)
function renderTable() {
  const tbl = document.querySelector('#students-table tbody');
  if (!tbl) return;
  const students = loadStudents();
  tbl.innerHTML = '';
  if (students.length === 0) {
    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.colSpan = 18;
    td.textContent = 'No students yet. Use "Add student" or click "Add sample students".';
    tr.appendChild(td);
    tbl.appendChild(tr);
    return;
  }

  students.forEach((s, idx) => {
    const abs = computeAbsences(s.sessions);
    const part = computeParticipation(s.participations);
    const msg = messageFor(abs, part);

    const tr = document.createElement('tr');
    // set highlighting class
    if (abs >= 5) tr.classList.add('row-bad');
    else if (abs >= 3) tr.classList.add('row-warning');
    else tr.classList.add('row-good');

    let html = '';
    html += `<td>${escapeHtml(s.student_id)}</td>`;
    html += `<td>${escapeHtml(s.last_name)}</td>`;
    html += `<td>${escapeHtml(s.first_name)}</td>`;
    // sessions columns (checkboxes)
    for (let i=0;i<SESSIONS;i++) {
      const checked = s.sessions[i] ? 'checked' : '';
      html += `<td><input type="checkbox" data-idx="${idx}" data-type="s" data-pos="${i}" ${checked}></td>`;
    }
    // participation columns
    for (let i=0;i<SESSIONS;i++) {
      const checked = s.participations[i] ? 'checked' : '';
      html += `<td><input type="checkbox" data-idx="${idx}" data-type="p" data-pos="${i}" ${checked}></td>`;
    }
    html += `<td>${abs}</td>`;
    html += `<td>${part}</td>`;
    html += `<td class="msg">${escapeHtml(msg)}</td>`;
    tr.innerHTML = html;
    tbl.appendChild(tr);
  });

  // attach listeners to checkboxes to update storage live
  document.querySelectorAll('#students-table input[type="checkbox"]').forEach(cb => {
    cb.addEventListener('change', (e) => {
      const el = e.target;
      const idx = parseInt(el.dataset.idx, 10);
      const type = el.dataset.type; // 's' or 'p'
      const pos = parseInt(el.dataset.pos, 10);
      const students = loadStudents();
      if (!students[idx]) return;
      if (type === 's') students[idx].sessions[pos] = el.checked;
      else students[idx].participations[pos] = el.checked;
      saveStudents(students);
      renderTable(); // re-render for updated counts & colors
    });
  });
}

// escape helper
function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/[&<>"']/g, function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});
}

// form validation + add (for add-student.html)
function initAddForm() {
  const form = document.getElementById('add-form');
  if (!form) return;
  const idEl = document.getElementById('student_id');
  const lastEl = document.getElementById('last_name');
  const firstEl = document.getElementById('first_name');
  const emailEl = document.getElementById('email');

  const errId = document.getElementById('err-id');
  const errLast = document.getElementById('err-last');
  const errFirst = document.getElementById('err-first');
  const errEmail = document.getElementById('err-email');
  const success = document.getElementById('form-success');

  function clearErrors() {
    errId.textContent = ''; errLast.textContent=''; errFirst.textContent=''; errEmail.textContent=''; success.textContent='';
  }

  form.addEventListener('submit', (ev) => {
    ev.preventDefault();
    clearErrors();
    let ok = true;
    const id = idEl.value.trim();
    const last = lastEl.value.trim();
    const first = firstEl.value.trim();
    const email = emailEl.value.trim();

    if (!/^[0-9]+$/.test(id)) { errId.textContent = 'Student ID must be numbers only and not empty.'; ok = false; }
    if (!/^[A-Za-z\u0600-\u06FF\- ]+$/.test(last)) { errLast.textContent = 'Last Name must contain letters only.'; ok = false; }
    if (!/^[A-Za-z\u0600-\u06FF\- ]+$/.test(first)) { errFirst.textContent = 'First Name must contain letters only.'; ok = false; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { errEmail.textContent = 'Email must be a valid format.'; ok = false; }

    if (!ok) return;

    // read default checkboxes
    const sessions = [];
    const participations = [];
    for (let i=0;i<SESSIONS;i++) {
      const s = document.querySelector(`.defaultS[data-index="${i}"]`);
      const p = document.querySelector(`.defaultP[data-index="${i}"]`);
      sessions.push(!!(s && s.checked));
      participations.push(!!(p && p.checked));
    }

    const students = loadStudents();
    // avoid duplicate id: if exists overwrite
    const existing = students.findIndex(x => x.student_id === id);
    const studentObj = { student_id: id, last_name: last, first_name: first, email: email, sessions, participations };
    if (existing >= 0) students[existing] = studentObj;
    else students.push(studentObj);
    saveStudents(students);
    success.textContent = 'Student added successfully. Redirecting to list...';
    setTimeout(()=>{ window.location.href = 'index.html'; }, 800);
  });
}

// buttons and init for index page
function initIndexPage() {
  const addSampleBtn = document.getElementById('add-sample');
  const clearBtn = document.getElementById('clear-all');
  if (addSampleBtn) {
    addSampleBtn.addEventListener('click', () => {
      const curr = loadStudents();
      const samples = sampleStudents();
      saveStudents(curr.concat(samples));
      renderTable();
    });
  }
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      if (confirm('Delete all students?')) {
        localStorage.removeItem(STORAGE_KEY);
        renderTable();
      }
    });
  }
}

// init on DOMContent
document.addEventListener('DOMContentLoaded', () => {
  renderTable();
  initIndexPage();
  initAddForm();
});
